#include "ui/pages/CategoriesPage.h"

#include <QHBoxLayout>
#include <QInputDialog>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>

#include "ui/common/Msg.h"
#include "ui/common/TableUtil.h"
#include "util/TextUtil.h"

CategoriesPage::CategoriesPage(QWidget* parent) : Page(parent) {
    auto* title = new QLabel("دسته‌بندی‌ها");
    title->setObjectName("PageTitle");

    newName_ = new QLineEdit;
    newName_->setPlaceholderText("نام دسته‌بندی جدید را بنویسید و Enter بزنید...");

    auto* addButton = new QPushButton("+ افزودن دسته‌بندی");
    addButton->setObjectName("Primary");
    auto* renameButton = new QPushButton("تغییر نام");
    auto* deleteButton = new QPushButton("حذف");
    deleteButton->setObjectName("Danger");

    auto* bar = new QHBoxLayout;
    bar->setSpacing(8);
    bar->addWidget(newName_, 1);
    bar->addWidget(addButton);
    bar->addWidget(renameButton);
    bar->addWidget(deleteButton);

    table_ = TableUtil::create({"نام دسته‌بندی", "تعداد کتاب"});
    table_->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);

    count_ = new QLabel;
    count_->setObjectName("PageSubtitle");

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(28, 24, 28, 20);
    layout->setSpacing(14);
    layout->addWidget(title);
    layout->addLayout(bar);
    layout->addWidget(table_, 1);
    layout->addWidget(count_);

    connect(newName_, &QLineEdit::returnPressed, this, &CategoriesPage::addCategory);
    connect(addButton, &QPushButton::clicked, this, &CategoriesPage::addCategory);
    connect(renameButton, &QPushButton::clicked, this, &CategoriesPage::renameSelected);
    connect(deleteButton, &QPushButton::clicked, this, &CategoriesPage::deleteSelected);
    connect(table_, &QTableWidget::cellDoubleClicked, this, [this] { renameSelected(); });
}

void CategoriesPage::refresh() {
    const QList<Category> categories = repo_.list();
    table_->setRowCount(0);
    table_->setRowCount(categories.size());
    int row = 0;
    for (const Category& c : categories) {
        auto* nameItem = TableUtil::item(c.name);
        nameItem->setData(Qt::UserRole, c.id);
        table_->setItem(row, 0, nameItem);
        table_->setItem(row, 1, TableUtil::item(TextUtil::fa(c.bookCount), true));
        ++row;
    }
    count_->setText(TextUtil::fa(categories.size()) + " دسته‌بندی");
}

void CategoriesPage::addCategory() {
    QString error;
    if (!repo_.add(newName_->text(), &error)) {
        Msg::warn(this, "دسته‌بندی", error);
        return;
    }
    newName_->clear();
    refresh();
}

void CategoriesPage::renameSelected() {
    const qint64 id = TableUtil::currentId(table_);
    if (!id) {
        Msg::info(this, "تغییر نام", "ابتدا یک دسته‌بندی را از لیست انتخاب کنید.");
        return;
    }
    QInputDialog dlg(this);
    dlg.setWindowTitle("تغییر نام دسته‌بندی");
    dlg.setLabelText("نام جدید:");
    dlg.setTextValue(table_->item(table_->currentRow(), 0)->text());
    dlg.setOkButtonText("ذخیره");
    dlg.setCancelButtonText("انصراف");
    if (dlg.exec() != QDialog::Accepted) return;

    QString error;
    if (!repo_.rename(id, dlg.textValue(), &error)) {
        Msg::warn(this, "خطا", error);
        return;
    }
    refresh();
}

void CategoriesPage::deleteSelected() {
    const qint64 id = TableUtil::currentId(table_);
    if (!id) {
        Msg::info(this, "حذف", "ابتدا یک دسته‌بندی را از لیست انتخاب کنید.");
        return;
    }
    const QString name = table_->item(table_->currentRow(), 0)->text();
    const int books = TextUtil::toLatinDigits(table_->item(table_->currentRow(), 1)->text()).toInt();

    QString text = "دسته‌بندی «" + name + "» حذف شود؟";
    if (books > 0)
        text += "\n\n" + TextUtil::fa(books) +
                " کتاب در این دسته هستند. کتاب‌ها حذف نمی‌شوند و فقط دسته‌بندی‌شان خالی می‌شود.";
    if (!Msg::confirm(this, "حذف دسته‌بندی", text, "حذف", "انصراف")) return;

    QString error;
    if (!repo_.remove(id, &error)) {
        Msg::warn(this, "خطا", error);
        return;
    }
    refresh();
}
