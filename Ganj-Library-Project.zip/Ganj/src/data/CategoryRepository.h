#pragma once
#include <QList>
#include <QString>

#include "core/Models.h"

class CategoryRepository {
public:
    QList<Category> list() const;
    bool add(const QString& name, QString* error = nullptr) const;
    bool rename(qint64 id, const QString& newName, QString* error = nullptr) const;
    // Removes the category; books that used it are kept and just lose their category.
    bool remove(qint64 id, QString* error = nullptr) const;

    // Registers a category name if it does not exist yet (used when saving / importing books)
    static void ensure(const QString& name);
};
